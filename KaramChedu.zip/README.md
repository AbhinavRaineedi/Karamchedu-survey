# Karamchedu Village Survey Application

A beautiful, modern web application designed to collect survey data from Below Poverty Line (BPL) families in Karamchedu village, Andhra Pradesh, India. The application helps identify needs for government schemes in Education, Health, and Elder Care.

## Features

### 📋 Survey Form
- **Household Information**: Basic family details, contact information, BPL card details
- **Education Assessment**: Children enrollment, scholarship needs, digital access
- **Health Assessment**: Medical needs, insurance requirements, sanitation access
- **Elder Care Assessment**: Pension status, medical assistance, daily living support
- **Other Needs**: Additional government schemes and comments

### 📊 Data Management
- **View Responses**: Table view of all survey responses with search functionality
- **Export Data**: Download data as CSV file for analysis in Excel
- **Summary Report**: Generate statistical summary with recommendations
- **Local Storage**: Data is saved locally in the browser

### 🎨 User Experience
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Modern UI**: Beautiful gradient design with smooth animations
- **Easy Navigation**: Tab-based interface for different functions
- **Form Validation**: Required field validation and conditional questions

## How to Use

### 1. Getting Started
1. Open `index.html` in any modern web browser
2. The application will load automatically
3. No internet connection required after initial load

### 2. Collecting Survey Data
1. Click on "Survey Form" tab (default)
2. Fill out all required fields marked with *
3. Conditional questions will appear based on your answers
4. Click "Submit Survey" to save the response
5. A success message will appear confirming the submission

### 3. Viewing Data
1. Click on "View Data" tab
2. All submitted responses are displayed in a table
3. Use the search box to filter responses
4. Click "Refresh" to reload the data

### 4. Exporting Data
1. Click on "Export Data" tab
2. **Export to CSV**: Downloads all survey responses as a spreadsheet
3. **Export Summary**: Downloads a statistical summary with recommendations
4. Files will be saved to your default downloads folder

## Survey Questions

### Household Information
- Name of Head of Family
- Address
- Phone Number
- Number of Family Members
- BPL Card Number (optional)
- Caste/Community (optional)

### Education
- Number of children (0-18 years)
- Are all children enrolled in school?
- Reasons for not attending (if applicable)
- Need for scholarships or financial aid?
- Access to digital learning devices?
- Any child with special needs?

### Health
- Any family member with chronic illness?
- Details of illness (if applicable)
- Access to government health schemes?
- Need for health insurance?
- Access to clean drinking water?
- Access to toilets/sanitation?

### Elder Care
- Number of elderly (60+ years)
- Are they receiving old age pension?
- Any need for medical assistance?
- Any need for daily living assistance?

### Other Needs
- Any other government scheme you wish to benefit from?
- Any other comments or needs?

## Technical Details

### File Structure
```
karamchedu-survey/
├── index.html          # Main application file
├── styles.css          # CSS styles and responsive design
├── script.js           # JavaScript functionality
└── README.md           # This file
```

### Browser Compatibility
- Chrome (recommended)
- Firefox
- Safari
- Edge
- Mobile browsers

### Data Storage
- All data is stored locally in the browser's localStorage
- Data persists between browser sessions
- No data is sent to external servers
- Export files are generated locally

## Government Schemes Covered

The survey is designed to identify needs for various government schemes including:

### Education Schemes
- Mid-Day Meal Scheme
- Sarva Shiksha Abhiyan
- National Scholarship Portal
- Digital India initiatives

### Health Schemes
- Ayushman Bharat
- Aarogyasri
- PM-JAY
- National Health Mission

### Elder Care Schemes
- National Old Age Pension Scheme
- Indira Gandhi National Old Age Pension
- Vayoshreshtha Samman
- Senior Citizens Welfare Fund

## Recommendations for Implementation

1. **Data Collection**: Use this application to collect initial survey data
2. **Analysis**: Export data to Excel for detailed analysis
3. **Follow-up**: Create targeted intervention programs based on identified needs
4. **Monitoring**: Regular follow-up surveys to track progress
5. **Documentation**: Ensure proper documentation for BPL families

## Customization

### Adding New Questions
1. Edit the form section in `index.html`
2. Add corresponding JavaScript handling in `script.js`
3. Update CSV export headers and data mapping

### Changing Colors/Theme
1. Modify CSS variables in `styles.css`
2. Update gradient colors and accent colors
3. Adjust font families and sizes as needed

### Adding New Features
1. Extend the JavaScript functionality in `script.js`
2. Add new tabs or sections in `index.html`
3. Update the CSS for new UI elements

## Support

For technical support or customization requests, please contact the development team.

## License

This application is created for the benefit of Karamchedu village and its residents. Please use responsibly and ensure data privacy is maintained.

---

**Note**: This application works entirely offline and stores data locally. For production use, consider implementing a backend server for data storage and user authentication. 