// Global variables
let surveyData = [];
let currentTab = 'survey';

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    loadData();
    setupEventListeners();
    updateStats();
});

// Initialize the application
function initializeApp() {
    // Load existing data from localStorage
    const savedData = localStorage.getItem('karamcheduSurveyData');
    if (savedData) {
        surveyData = JSON.parse(savedData);
    }
}

// Setup all event listeners
function setupEventListeners() {
    // Navigation
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', () => switchTab(btn.dataset.tab));
    });

    // Form submission
    document.getElementById('surveyForm').addEventListener('submit', handleFormSubmit);

    // Form field dependencies
    setupFormDependencies();

    // Export buttons
    document.getElementById('exportCSV').addEventListener('click', exportToCSV);
    document.getElementById('exportSummary').addEventListener('click', exportSummary);

    // Search functionality
    document.getElementById('searchInput').addEventListener('input', filterData);
    document.getElementById('refreshData').addEventListener('click', loadData);

    // Modal close
    document.querySelector('.close').addEventListener('click', closeModal);
    window.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
            closeModal();
        }
    });
}

// Switch between tabs
function switchTab(tabName) {
    // Update navigation buttons
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

    // Update tab content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById(tabName).classList.add('active');

    currentTab = tabName;

    // Load data if switching to data tab
    if (tabName === 'data') {
        loadData();
    }
}

// Setup form field dependencies
function setupFormDependencies() {
    // Show/hide not enrolled reason field
    document.getElementById('allEnrolled').addEventListener('change', function() {
        const reasonField = document.getElementById('notEnrolledReason');
        if (this.value === 'No') {
            reasonField.style.display = 'block';
        } else {
            reasonField.style.display = 'none';
            document.getElementById('notEnrolledReasonText').value = '';
        }
    });

    // Show/hide illness details field
    document.getElementById('chronicIllness').addEventListener('change', function() {
        const detailsField = document.getElementById('illnessDetails');
        if (this.value === 'Yes') {
            detailsField.style.display = 'block';
        } else {
            detailsField.style.display = 'none';
            document.getElementById('illnessDetailsText').value = '';
        }
    });
}

// Handle form submission
function handleFormSubmit(e) {
    e.preventDefault();

    const formData = new FormData(e.target);
    const surveyResponse = {
        id: Date.now(),
        timestamp: new Date().toISOString(),
        date: new Date().toLocaleDateString('en-IN'),
        ...Object.fromEntries(formData)
    };

    // Add to data array
    surveyData.push(surveyResponse);

    // Save to localStorage
    saveData();

    // Show success modal
    showSuccessModal();

    // Reset form
    e.target.reset();

    // Hide conditional fields
    document.getElementById('notEnrolledReason').style.display = 'none';
    document.getElementById('illnessDetails').style.display = 'none';

    // Update stats
    updateStats();
}

// Save data to localStorage
function saveData() {
    localStorage.setItem('karamcheduSurveyData', JSON.stringify(surveyData));
}

// Load and display data
function loadData() {
    const tableBody = document.getElementById('dataTableBody');
    tableBody.innerHTML = '';

    surveyData.forEach(response => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${response.date}</td>
            <td>${response.headName || '-'}</td>
            <td>${response.phone || '-'}</td>
            <td>${response.familyMembers || '-'}</td>
            <td>${response.childrenCount || '-'}</td>
            <td>${response.elderlyCount || '-'}</td>
            <td>${response.needScholarship === 'Yes' ? 'Yes' : 'No'}</td>
            <td>${response.healthInsurance === 'Yes' ? 'Yes' : 'No'}</td>
            <td>${response.dailyAssistance === 'Yes' ? 'Yes' : 'No'}</td>
        `;
        tableBody.appendChild(row);
    });
}

// Filter data based on search input
function filterData() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const tableBody = document.getElementById('dataTableBody');
    const rows = tableBody.querySelectorAll('tr');

    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        if (text.includes(searchTerm)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// Update statistics
function updateStats() {
    document.getElementById('totalResponses').textContent = surveyData.length;
    
    const educationNeeds = surveyData.filter(r => r.needScholarship === 'Yes').length;
    document.getElementById('educationNeeds').textContent = educationNeeds;
    
    const healthNeeds = surveyData.filter(r => r.healthInsurance === 'Yes').length;
    document.getElementById('healthNeeds').textContent = healthNeeds;
    
    const elderCareNeeds = surveyData.filter(r => r.dailyAssistance === 'Yes').length;
    document.getElementById('elderCareNeeds').textContent = elderCareNeeds;
}

// Export data to CSV
function exportToCSV() {
    if (surveyData.length === 0) {
        alert('No data to export!');
        return;
    }

    const headers = [
        'Date',
        'Head of Family',
        'Address',
        'Phone Number',
        'Family Members',
        'BPL Card Number',
        'Caste/Community',
        'Children Count',
        'All Enrolled',
        'Not Enrolled Reason',
        'Need Scholarship',
        'Digital Devices',
        'Special Needs',
        'Chronic Illness',
        'Illness Details',
        'Health Schemes',
        'Health Insurance',
        'Clean Water',
        'Sanitation',
        'Elderly Count',
        'Old Age Pension',
        'Medical Assistance',
        'Daily Assistance',
        'Other Schemes',
        'Comments'
    ];

    const csvContent = [
        headers.join(','),
        ...surveyData.map(response => [
            response.date,
            `"${response.headName || ''}"`,
            `"${response.address || ''}"`,
            response.phone || '',
            response.familyMembers || '',
            response.bplCard || '',
            `"${response.caste || ''}"`,
            response.childrenCount || '',
            response.allEnrolled || '',
            `"${response.notEnrolledReason || ''}"`,
            response.needScholarship || '',
            response.digitalDevices || '',
            response.specialNeeds || '',
            response.chronicIllness || '',
            `"${response.illnessDetails || ''}"`,
            response.healthSchemes || '',
            response.healthInsurance || '',
            response.cleanWater || '',
            response.sanitation || '',
            response.elderlyCount || '',
            response.oldAgePension || '',
            response.medicalAssistance || '',
            response.dailyAssistance || '',
            `"${response.otherSchemes || ''}"`,
            `"${response.comments || ''}"`
        ].join(','))
    ].join('\n');

    downloadCSV(csvContent, 'karamchedu_survey_data.csv');
}

// Export summary report
function exportSummary() {
    if (surveyData.length === 0) {
        alert('No data to export!');
        return;
    }

    const totalResponses = surveyData.length;
    const educationNeeds = surveyData.filter(r => r.needScholarship === 'Yes').length;
    const healthNeeds = surveyData.filter(r => r.healthInsurance === 'Yes').length;
    const elderCareNeeds = surveyData.filter(r => r.dailyAssistance === 'Yes').length;
    const totalChildren = surveyData.reduce((sum, r) => sum + (parseInt(r.childrenCount) || 0), 0);
    const totalElderly = surveyData.reduce((sum, r) => sum + (parseInt(r.elderlyCount) || 0), 0);

    const summary = [
        'Karamchedu Village Survey Summary Report',
        `Generated on: ${new Date().toLocaleDateString('en-IN')}`,
        '',
        'Key Statistics:',
        `Total Survey Responses: ${totalResponses}`,
        `Total Children (0-18 years): ${totalChildren}`,
        `Total Elderly (60+ years): ${totalElderly}`,
        '',
        'Needs Assessment:',
        `Families needing Education Support: ${educationNeeds} (${((educationNeeds/totalResponses)*100).toFixed(1)}%)`,
        `Families needing Health Support: ${healthNeeds} (${((healthNeeds/totalResponses)*100).toFixed(1)}%)`,
        `Families needing Elder Care: ${elderCareNeeds} (${((elderCareNeeds/totalResponses)*100).toFixed(1)}%)`,
        '',
        'Recommendations:',
        '1. Focus on education schemes for families with children',
        '2. Prioritize health insurance and medical assistance programs',
        '3. Implement elder care support programs',
        '4. Ensure proper documentation for BPL families',
        '5. Regular follow-up and monitoring of scheme implementation'
    ].join('\n');

    downloadCSV(summary, 'karamchedu_survey_summary.txt');
}

// Download file helper
function downloadCSV(content, filename) {
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}

// Show success modal
function showSuccessModal() {
    const modal = document.getElementById('successModal');
    modal.style.display = 'block';
    
    // Add success animation
    const modalContent = modal.querySelector('.modal-content');
    modalContent.classList.add('success-animation');
    
    setTimeout(() => {
        modalContent.classList.remove('success-animation');
    }, 600);
}

// Close modal
function closeModal() {
    document.getElementById('successModal').style.display = 'none';
}

// Utility function to format phone numbers
function formatPhoneNumber(phone) {
    const cleaned = phone.replace(/\D/g, '');
    const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
    if (match) {
        return '(' + match[1] + ') ' + match[2] + '-' + match[3];
    }
    return phone;
}

// Add some sample data for demonstration (remove in production)
function addSampleData() {
    if (surveyData.length === 0) {
        const sampleData = [
            {
                id: Date.now() - 86400000,
                timestamp: new Date(Date.now() - 86400000).toISOString(),
                date: new Date(Date.now() - 86400000).toLocaleDateString('en-IN'),
                headName: 'Rama Rao',
                address: 'Karamchedu Village, Prakasam District, AP',
                phone: '9876543210',
                familyMembers: '5',
                bplCard: 'BPL123456',
                caste: 'BC',
                childrenCount: '2',
                allEnrolled: 'Yes',
                needScholarship: 'Yes',
                digitalDevices: 'No',
                specialNeeds: 'No',
                chronicIllness: 'No',
                healthSchemes: 'No',
                healthInsurance: 'Yes',
                cleanWater: 'Yes',
                sanitation: 'No',
                elderlyCount: '1',
                oldAgePension: 'No',
                medicalAssistance: 'Yes',
                dailyAssistance: 'No',
                otherSchemes: 'Housing scheme',
                comments: 'Need better sanitation facilities'
            },
            {
                id: Date.now() - 43200000,
                timestamp: new Date(Date.now() - 43200000).toISOString(),
                date: new Date(Date.now() - 43200000).toLocaleDateString('en-IN'),
                headName: 'Lakshmi Devi',
                address: 'Karamchedu Village, Prakasam District, AP',
                phone: '8765432109',
                familyMembers: '4',
                bplCard: 'BPL789012',
                caste: 'SC',
                childrenCount: '1',
                allEnrolled: 'No',
                notEnrolledReason: 'Financial constraints',
                needScholarship: 'Yes',
                digitalDevices: 'No',
                specialNeeds: 'No',
                chronicIllness: 'Yes',
                illnessDetails: 'Diabetes',
                healthSchemes: 'Yes',
                healthInsurance: 'Yes',
                cleanWater: 'Yes',
                sanitation: 'Yes',
                elderlyCount: '0',
                oldAgePension: 'No',
                medicalAssistance: 'No',
                dailyAssistance: 'No',
                otherSchemes: 'Education support',
                comments: 'Need help with medical expenses'
            }
        ];
        
        surveyData = sampleData;
        saveData();
        updateStats();
        loadData();
    }
}

// Uncomment the line below to add sample data for demonstration
// addSampleData(); 